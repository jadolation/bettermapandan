# Better Mapandan GIS V3.1 — Implementation handoff

This package contains the updated V3.1 plan, 15-barangay ADM4 candidate GeoJSON and preview, two barangay reference maps, and four **original historical physical map posters**. All files are unmodified source/reference inputs except the previously extracted candidate GeoJSON. None of the posters have been georeferenced, and no changes have been made to the website.

Read `GIS_IMPLEMENTATION_PLAN_V3_1.md` first. Do not deploy the posters by stretching them into an arbitrary bounding box; QGIS registration and evaluation are required.
